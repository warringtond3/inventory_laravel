

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Category Details</h1>
    <div class="form-group">
        <label for="CategoryName">Category Name</label>
        <input type="text" id="CategoryName" class="form-control" value="<?php echo e($category->CategoryName); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="Description">Description</label>
        <textarea id="Description" class="form-control" readonly><?php echo e($category->Description); ?></textarea>
    </div>
    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-primary">Back to Categories</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\Inventory\Inventory\resources\views\categories\show.blade.php ENDPATH**/ ?>