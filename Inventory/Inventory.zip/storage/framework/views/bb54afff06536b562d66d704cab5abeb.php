

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Supplier</h1>
    <form action="<?php echo e(route('suppliers.update', $supplier->SupplierID)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="SupplierName">Supplier Name</label>
            <input type="text" name="SupplierName" id="SupplierName" class="form-control" value="<?php echo e($supplier->SupplierName); ?>" required>
        </div>
        <div class="form-group">
            <label for="ContactName">Contact Name</label>
            <input type="text" name="ContactName" id="ContactName" class="form-control" value="<?php echo e($supplier->ContactName); ?>">
        </div>
        <div class="form-group">
            <label for="Address">Address</label>
            <input type="text" name="Address" id="Address" class="form-control" value="<?php echo e($supplier->Address); ?>">
        </div>
        <div class="form-group">
            <label for="City">City</label>
            <input type="text" name="City" id="City" class="form-control" value="<?php echo e($supplier->City); ?>">
        </div>
        <div class="form-group">
            <label for="PostalCode">Postal Code</label>
            <input type="text" name="PostalCode" id="PostalCode" class="form-control" value="<?php echo e($supplier->PostalCode); ?>">
        </div>
        <div class="form-group">
            <label for="Country">Country</label>
            <input type="text" name="Country" id="Country" class="form-control" value="<?php echo e($supplier->Country); ?>">
        </div>
        <div class="form-group">
            <label for="Phone">Phone</label>
            <input type="text" name="Phone" id="Phone" class="form-control" value="<?php echo e($supplier->Phone); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\Inventory\Inventory\resources\views\suppliers\edit.blade.php ENDPATH**/ ?>