

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create New Product</h1>
    <form action="<?php echo e(route('products.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="ProductName">Product Name</label>
            <input type="text" name="ProductName" id="ProductName" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="CategoryID">Category</label>
            <select name="CategoryID" id="CategoryID" class="form-control" required>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->CategoryID); ?>"><?php echo e($category->CategoryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="SupplierID">Supplier</label>
            <select name="SupplierID" id="SupplierID" class="form-control" required>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($supplier->SupplierID); ?>"><?php echo e($supplier->SupplierName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="UnitPrice">Unit Price</label>
            <input type="number" step="0.01" name="UnitPrice" id="UnitPrice" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="QuantityPerUnit">Quantity Per Unit</label>
            <input type="text" name="QuantityPerUnit" id="QuantityPerUnit" class="form-control">
        </div>
        <div class="form-group">
            <label for="UnitsInStock">Units In Stock</label>
            <input type="number" name="UnitsInStock" id="UnitsInStock" class="form-control">
        </div>
        <div class="form-group">
            <label for="ReorderLevel">Reorder Level</label>
            <input type="number" name="ReorderLevel" id="ReorderLevel" class="form-control">
        </div>
        <div class="form-group">
            <label for="Discontinued">Discontinued</label>
            <input type="checkbox" name="Discontinued" id="Discontinued">
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\Inventory\Inventory\resources\views\products\create.blade.php ENDPATH**/ ?>