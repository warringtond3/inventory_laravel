

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Product Details</h1>
    <div class="form-group">
        <label for="ProductName">Product Name</label>
        <input type="text" id="ProductName" class="form-control" value="<?php echo e($product->ProductName); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="CategoryName">Category</label>
        <input type="text" id="CategoryName" class="form-control" value="<?php echo e($product->category->CategoryName); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="SupplierName">Supplier</label>
        <input type="text" id="SupplierName" class="form-control" value="<?php echo e($product->supplier->SupplierName); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="UnitPrice">Unit Price</label>
        <input type="text" id="UnitPrice" class="form-control" value="<?php echo e($product->UnitPrice); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="QuantityPerUnit">Quantity Per Unit</label>
        <input type="text" id="QuantityPerUnit" class="form-control" value="<?php echo e($product->QuantityPerUnit); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="UnitsInStock">Units In Stock</label>
        <input type="text" id="UnitsInStock" class="form-control" value="<?php echo e($product->UnitsInStock); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="ReorderLevel">Reorder Level</label>
        <input type="text" id="ReorderLevel" class="form-control" value="<?php echo e($product->ReorderLevel); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="Discontinued">Discontinued</label>
        <input type="checkbox" id="Discontinued" disabled <?php echo e($product->Discontinued ? 'checked' : ''); ?>>
    </div>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Back to Products</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\Inventory\Inventory\resources\views\products\show.blade.php ENDPATH**/ ?>