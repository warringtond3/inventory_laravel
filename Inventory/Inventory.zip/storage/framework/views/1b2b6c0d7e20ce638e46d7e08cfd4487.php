

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Products</h1>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3">Add New Product</a>

    <?php if($products->isEmpty()): ?>
        <p>No products found.</p>
    <?php else: ?>
        <table class="table table-bordered" id="myTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Supplier</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->ProductID); ?></td>
                        <td><?php echo e($product->ProductName); ?></td>
                        <td><?php echo e($product->category->CategoryName); ?></td>
                        <td><?php echo e($product->supplier->SupplierName); ?></td>
                        <td><?php echo e($product->UnitPrice); ?></td>
                        <td>
                            <a href="<?php echo e(route('products.edit', $product->ProductID)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('products.destroy', $product->ProductID)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                            <a href="<?php echo e(route('products.show', $product->ProductID)); ?>" class="btn btn-sm btn-info">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<script>
    $(document).ready(function () {
        $('#myTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\Inventory\Inventory\resources\views\products\index.blade.php ENDPATH**/ ?>