

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Suppliers</h1>
    <a href="<?php echo e(route('suppliers.create')); ?>" class="btn btn-primary mb-3">Add New Supplier</a>

    <?php if($suppliers->isEmpty()): ?>
        <p>No suppliers found.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Supplier Name</th>
                    <th>Contact Name</th>
                    <th>City</th>
                    <th>Country</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($supplier->SupplierID); ?></td>
                        <td><?php echo e($supplier->SupplierName); ?></td>
                        <td><?php echo e($supplier->ContactName); ?></td>
                        <td><?php echo e($supplier->City); ?></td>
                        <td><?php echo e($supplier->Country); ?></td>
                        <td>
                            <a href="<?php echo e(route('suppliers.edit', $supplier->SupplierID)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('suppliers.destroy', $supplier->SupplierID)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this supplier?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                            <a href="<?php echo e(route('suppliers.show', $supplier->SupplierID)); ?>" class="btn btn-sm btn-info">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\Inventory\Inventory\resources\views\suppliers\index.blade.php ENDPATH**/ ?>