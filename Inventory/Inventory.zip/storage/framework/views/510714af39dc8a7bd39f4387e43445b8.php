

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Supplier Details</h1>
    <div class="form-group">
        <label for="SupplierName">Supplier Name</label>
        <input type="text" id="SupplierName" class="form-control" value="<?php echo e($supplier->SupplierName); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="ContactName">Contact Name</label>
        <input type="text" id="ContactName" class="form-control" value="<?php echo e($supplier->ContactName); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="Address">Address</label>
        <input type="text" id="Address" class="form-control" value="<?php echo e($supplier->Address); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="City">City</label>
        <input type="text" id="City" class="form-control" value="<?php echo e($supplier->City); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="PostalCode">Postal Code</label>
        <input type="text" id="PostalCode" class="form-control" value="<?php echo e($supplier->PostalCode); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="Country">Country</label>
        <input type="text" id="Country" class="form-control" value="<?php echo e($supplier->Country); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="Phone">Phone</label>
        <input type="text" id="Phone" class="form-control" value="<?php echo e($supplier->Phone); ?>" readonly>
    </div>
    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-primary">Back to Suppliers</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\Inventory\Inventory\resources\views\suppliers\show.blade.php ENDPATH**/ ?>